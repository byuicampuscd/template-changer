/*jslint plusplus: true, node: true, devel: true */

"use strict";
module.exports = {
   mode: {
      NORMAL: 0,
      IF: 1,
      IF_ELSE: 2
   }
};